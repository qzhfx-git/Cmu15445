Reference
=========

.. doxygenstruct:: ft_border_chars
.. doxygenfunction:: ft_create_table
.. doxygenfunction:: ft_destroy_table
