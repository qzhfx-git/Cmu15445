Introduction
============

The C library `libfort` provides data structures and functions
to generate tables.